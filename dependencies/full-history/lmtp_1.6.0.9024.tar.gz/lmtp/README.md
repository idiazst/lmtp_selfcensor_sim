
<!-- README.md is generated from README.Rmd. Please edit that file -->

# lmtp <img src="man/figures/lmtp.png" align="right" height="139"/></a>

## Self-censoring development branch

This is the `self-censoring` branch of [idiazst/lmtp](https://github.com/idiazst/lmtp/tree/self-censoring),
a fork of [nt-williams/lmtp](https://github.com/nt-williams/lmtp). The package
name remains **lmtp**. It includes Herb Susmann's pooled-curve implementation,
the previously ported upstream repairs, pooled SDR and logistic TMLE,
and the observed-history self-censoring estimator `lmtp_bridge()`.

Full-history adjustment is available through `lmtp_full_history()`. It accepts
separate `alpha`, `d`, and `t` functions: known treatment at no-visit times,
the visit policy, and the randomized no-visit policy. It rebuilds a pseudo-outcome
at every time, estimates both policy ratios by classification, and adds a
horizon-specific adjoint correction for every bridge in the recursion.

```r
fit <- lmtp_full_history(
  data, trt = c("A1", "A2"), outcome = c("C2", "C3"),
  measurement = c("R1", "R2", "R3"),
  health = list("C1", "C2", "C3"),
  alpha = function(data, trt) rep(0, nrow(data)),
  d = function(data, trt) rep(1, nrow(data)),
  t = function(data, trt, epsilon) as.numeric(epsilon < .35),
  mtp = FALSE, k = 1, estimator = "tmle", folds = 3
)
tidy(fit)
```

Baseline health must be fully observed. `health` and `measurement` include
baseline; `outcome` and `trt` begin with the first treatment transition.
The `t` callback receives treatment already set to `alpha`; it cannot read
future outcomes or latent unrecorded health. `randomizer(n, time)` draws from
the known continuation randomizer law for classification. `epsilon` contains
matching quadrature nodes for regression integration; increase their number
when checking integration accuracy. No-visit treatment is checked against
`alpha` before fitting. Retained states use `k` health times and their
intervening treatments. The bridge library should use inverse-logit links
so fitted inverse probabilities are at least one; raw fits are never clipped.

The full-history study is kept separately in
[`lmtp_selfcensor_sim/studies/full-history`](https://github.com/idiazst/lmtp_selfcensor_sim/tree/full-history-adjustment/studies/full-history).


`lmtp_bridge()` constructs or accepts the outer splits, then passes the same
training-person splits to SuperLearner, cmbridge and penalty selection. Both
sequential estimators receive the one-step bridge/adjoint correction.
The generic conditional-moment learners live in **cmbridge**; study DGPs,
launchers and results live in [lmtp_selfcensor_sim](https://github.com/idiazst/lmtp_selfcensor_sim).
See [SELF-CENSORING.md](SELF-CENSORING.md) for the branch's API and tests.

<!-- badges: start -->

[![CRAN
status](https://www.r-pkg.org/badges/version/lmtp)](https://CRAN.R-project.org/package=lmtp)
![](http://cranlogs.r-pkg.org/badges/grand-total/lmtp) [![R build
status](https://github.com/nt-williams/lmtp/workflows/R-CMD-check/badge.svg)](https://github.com/nt-williams/lmtp/actions)
[![codecov](https://codecov.io/gh/nt-williams/lmtp/branch/master/graph/badge.svg)](https://app.codecov.io/gh/nt-williams/lmtp)
[![License: GPL
v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Project Status: Active – The project has reached a stable, usable
state and is being actively
developed.](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)

<!-- badges: end -->

> Non-parametric Causal Effects of Feasible Interventions Based on
> Modified Treatment Policies

Nick Williams and Ivan Diaz

------------------------------------------------------------------------

**lmtp** is an R package that provides an estimation framework for the
casual effects of feasible interventions based on point-treatment and
longitudinal modified treatment policies as described in Diaz, Williams,
Hoffman, and Schenck (2020). Two primary estimators are supported, a
targeted maximum likelihood (TML) estimator and a sequentially doubly
robust (SDR) estimator (a G-computation and an inverse probability of
treatment weighting estimator are provided for the sake of being
thorough but their use is recommended against in favor of the TML and
SDR estimators). Both binary and continuous outcomes (both with
censoring) are allowed. **lmtp** is built atop the
[`SuperLearner`](https://CRAN.R-project.org/package=SuperLearner)
package to utilize ensemble machine learning for estimation. The
treatment mechanism is estimated via a density ratio classification
procedure irrespective of treatment variable type providing decreased
computation time when treatment is continuous. Dynamic treatment regimes
are also supported.

A list of papers using **lmtp** is
[here](https://gist.github.com/nt-williams/15068f5849a67ff4d2cb7f2dcf97b3de).

For an in-depth look at the package’s functionality, please consult the
accompanying technical paper in [Observational
Studies](https://muse.jhu.edu/article/883479).

## Pooled curve estimators in this development branch

This branch extends Herb Susmann's `curve` implementation with upstream fixes,
externally supplied sample splits, and a pooled TMLE option. SDR remains the default.

```r
fit <- lmtp_curve(data, trt, outcome, baseline = baseline,
                  shift = policy, estimator = "tmle", folds = 5)
```

Both methods fit one pooled initial learner per recursive depth. TMLE then targets
each outcome time on its held-out fold. Use `folds = list(...)` with training and
validation row indices and `learner_folds = list(...)` with fold labels in each
outer training set's row order to coordinate cross-fitting with another package.
The returned object records both split plans. `folds = 1` is an in-sample analysis.

The learner backend now follows upstream `SuperLearner`; use `SL.*` learner names.
The common old names `glm`, `mean`, `ranger`, and `cv_glmnet` remain accepted.
For continuous or bridge-transformed responses, supply appropriate `bounds` and
`outcome_type = "continuous"`. The bridge and adjoint correction will be integrated
separately; they are not part of this pooled-estimator modification.

See [MODIFICATIONS.md](MODIFICATIONS.md) for implementation details and validation.

## Installation

**lmtp** can be installed from CRAN with:

``` r
install.packages("lmtp")
```

The stable, development version can be installed from GitHub with:

``` r
devtools::install_github("nt-williams/lmtp@devel")
```

A version allowing for different covariates sets for the treatment,
censoring, and outcome regressions:

``` r
devtools::install_github("nt-williams/lmtp@separate-variable-sets")
```

## What even is a modified treatment policy?

Modified treatment policies (MTP) are interventions that can depend on
the *natural* value of the treatment (the treatment value in the absence
of intervention). A key assumption for causal inference is the
*positivity assumption* which states that all observations have a
non-zero probability of experiencing a treatment value. **When working
with continuous or multivalued treatments, violations of the positivity
assumption are likely to occur. MTPs offer a solution to this problem.**

## Can lmtp estimate other effects?

Yes! **lmtp** can estimate the effects of deterministic, static
treatment effects (such as the ATE) and deterministic, dynamic treatment
regimes for binary, continuous, and survival outcomes.

### Features

| Feature                                                          | Status |
|------------------------------------------------------------------|:------:|
| Point treatment                                                  |   ✓    |
| Longitudinal treatment                                           |   ✓    |
| Modified treatment intervention                                  |   ✓    |
| Incremental Propensity Score Intervention (Using the risk ratio) |   ✓    |
| Static intervention                                              |   ✓    |
| Dynamic intervention                                             |   ✓    |
| Continuous treatment                                             |   ✓    |
| Binary treatment                                                 |   ✓    |
| Categorical treatment                                            |   ✓    |
| Multivariate treatment                                           |   ✓    |
| Missingness in treatment                                         |        |
| Continuous outcome                                               |   ✓    |
| Binary outcome                                                   |   ✓    |
| Censored outcome                                                 |   ✓    |
| Mediation                                                        |        |
| Survey weights                                                   |   ✓    |
| Super learner                                                    |   ✓    |
| Clustered data                                                   |   ✓    |
| Parallel processing                                              |   ✓    |
| Progress bars                                                    |   ✓    |

## Example

``` r
library(lmtp)

# the data: 4 treatment nodes with time varying covariates and a binary outcome
head(sim_t4)
#>   ID L_1 A_1 L_2 A_2 L_3 A_3 L_4 A_4 Y
#> 1  1   2   3   0   1   1   1   1   3 0
#> 2  2   2   1   1   4   0   3   1   2 0
#> 3  3   1   0   1   3   1   2   1   1 1
#> 4  4   1   0   0   3   1   3   1   2 0
#> 5  5   3   3   1   1   0   1   1   2 0
#> 6  6   1   0   0   2   0   3   1   4 0
```

We’re interested in a treatment policy, `d`, where exposure is decreased
by 1 only among subjects whose exposure won’t go below 1 if intervened
upon. The true population outcome under this policy is about 0.305.

``` r
# a treatment policy function to be applied at all time points
policy <- function(data, trt) {
  (data[[trt]] - 1) * (data[[trt]] - 1 >= 1) + data[[trt]] * (data[[trt]] - 1 < 1)
}
```

In addition to specifying a treatment policy, we need to specify our
treatment variables and time-varying covariates.

``` r
# treatment nodes, a character vector of length 4
A <- c("A_1", "A_2", "A_3", "A_4")
# time varying nodes, a list of length 4
L <- list(c("L_1"), c("L_2"), c("L_3"), c("L_4"))
```

We can now estimate the effect of our treatment policy, `d`. In this
example, we’ll use the cross-validated TML estimator with 10 folds.

``` r
lmtp_tmle(sim_t4, A, "Y", time_vary = L, shift = policy, mtp = TRUE, folds = 10)
```

## Data structure

#### Single time point

<img src="man/figures/pointtrt.png" height="300"/>

#### Time-varying exposure and confounders, not survival outcome

<img src="man/figures/timevary.png" height="300"/>

#### Single exposure, survival outcome

<img src="man/figures/survival.png" height="300"/>

#### Time-varying exposure and confounders, survival outcome

<img src="man/figures/timevarysurvival.png" height="300"/>

## Similar Implementations

A variety of other R packages perform similar tasks as **lmtp**.
However, **lmtp** is the only R package currently capable of estimating
causal effects for binary, categorical, and continuous exposures in both
the point treatment and longitudinal setting using traditional causal
effects or modified treatment policies.

- [`txshift`](https://github.com/nhejazi/txshift)  
- [`tmle3`](https://github.com/tlverse/tmle3)  
- [`tmle3shift`](https://github.com/tlverse/tmle3shift)
- [`ltmle`](https://CRAN.R-project.org/package=ltmle)  
- [`tmle`](https://CRAN.R-project.org/package=tmle)

## Citation

Please cite the following when using **lmtp** in publications. Citation
should include both the R package article and the paper establishing the
statistical methodology.

    @article{,
      title = {lmtp: An R package for estimating the causal effects of modified treatment policies},
      author = {Nicholas T Williams and Iván Díaz},
      journal = {Observational Studies},
      year = {2023},
      url = {https://muse.jhu.edu/article/883479}
    }

    @article{
      doi:10.1080/01621459.2021.1955691,
      author = {Iván Díaz and Nicholas Williams and Katherine L. Hoffman and Edward J. Schenck},
      title = {Non-parametric causal effects based on longitudinal modified treatment policies},
      journal = {Journal of the American Statistical Association},
      year  = {2021},
      doi = {10.1080/01621459.2021.1955691},
      URL = {https://doi.org/10.1080/01621459.2021.1955691},
    }

## References

Iván Díaz, Nicholas Williams, Katherine L. Hoffman & Edward J. Schenck
(2021) Non-parametric causal effects based on longitudinal modified
treatment policies, Journal of the American Statistical Association,
DOI: 10.1080/01621459.2021.1955691
